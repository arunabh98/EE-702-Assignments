Please refer to Report.html for a cleaner version of the report. Ipython notebooks render better in
HTML format.

Regards,
Arunabh Ghosh
Srivatsan Sridhar